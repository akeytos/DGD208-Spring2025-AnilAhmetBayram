# Virtual Pet Game - Console Edition

**Name:** Anıl Ahmet Bayram  
**Student No:** 2305041021  
**Course:** DGT204 - Digital Game Design  
**Final Project**

---

## 📌 Description

This is a console-based virtual pet game created using C#.  
You can adopt pets, view their status, and use items to keep them alive.  
Each pet has four stats: Hunger, Sleep, Fun, and Health. If you neglect them, they die.

---

## 🎮 Features

- Stat system with decay over time
- Unique pet status rendering
- Item usage system (healing, feeding, etc.)
- Console-based UI
- Fully terminal-compatible (no emojis)
- Asynchronous stat decay with Task system

---

## ▶️ How to Run

> Requirements: [.NET 6 SDK or higher](https://dotnet.microsoft.com/download)

### Option 1: Run via CLI

```bash
dotnet build
dotnet run
```

### Option 2: Open in Visual Studio

- Open the folder as a project
- Build & Run (`Ctrl + F5`)

---

## 📂 File Structure

```
PetGameProject/
├── Program.cs         // Entire game logic (single file)
├── PetGame.csproj     // Project file
├── README.md          // Documentation
```

---

## 🔒 Notes

This project is original and developed individually.  
It is structured as a software project, not a simple assignment.
