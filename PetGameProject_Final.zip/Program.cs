using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;

enum StatType
{
    Hunger,
    Sleep,
    Fun,
    Health
}

class Pet
{
    public string Name { get; set; }
    public int Hunger { get; set; } = 100;
    public int Sleep { get; set; } = 100;
    public int Fun { get; set; } = 100;
    public int Health { get; set; } = 100;
    public bool IsDead { get; private set; } = false;

    public Pet(string name)
    {
        Name = name;
    }

    public void IncreaseStat(StatType stat, int amount)
    {
        if (IsDead) return;
        switch (stat)
        {
            case StatType.Hunger: Hunger = Math.Min(100, Hunger + amount); break;
            case StatType.Sleep: Sleep = Math.Min(100, Sleep + amount); break;
            case StatType.Fun: Fun = Math.Min(100, Fun + amount); break;
            case StatType.Health: Health = Math.Min(100, Health + amount); break;
        }
    }

    public void DecreaseStat(StatType stat, int amount)
    {
        if (IsDead) return;
        switch (stat)
        {
            case StatType.Hunger: Hunger = Math.Max(0, Hunger - amount); break;
            case StatType.Sleep: Sleep = Math.Max(0, Sleep - amount); break;
            case StatType.Fun: Fun = Math.Max(0, Fun - amount); break;
        }
    }

    public void UpdateHealth()
    {
        if (IsDead) return;
        int dangerZone = 0;
        if (Hunger <= 0) dangerZone++;
        if (Sleep <= 0) dangerZone++;
        if (Fun <= 0) dangerZone++;
        Health = Math.Max(0, Health - (dangerZone * 5));
        if (Health <= 0)
        {
            IsDead = true;
            Console.WriteLine($"
{Name} couldn't handle the heat. Game over for them.");
        }
    }

    public string GetStatusIcon()
    {
        if (IsDead) return "[X]";
        if (Hunger < 30 || Sleep < 30 || Fun < 30 || Health < 30) return ":( ";
        if (Hunger < 50 || Sleep < 50 || Fun < 50 || Health < 50) return ":| ";
        return ":) ";
    }

    public override string ToString()
    {
        string stats = $"{GetStatusIcon()}{Name} | Hunger: {Hunger} | Sleep: {Sleep} | Fun: {Fun} | Health: {Health}";
        return IsDead ? $"~~{stats}~~" : stats;
    }
}

class Item
{
    public string Name { get; set; }
    public StatType StatAffected { get; set; }
    public int EffectAmount { get; set; }

    public Item(string name, StatType statAffected, int effectAmount)
    {
        Name = name;
        StatAffected = statAffected;
        EffectAmount = effectAmount;
    }
}

static class ItemDatabase
{
    public static List<Item> Items { get; } = new()
    {
        new Item("Snack Attack", StatType.Hunger, 30),
        new Item("Nap Bomb", StatType.Sleep, 40),
        new Item("Party Ball", StatType.Fun, 25),
        new Item("Bandage Pack", StatType.Health, 50)
    };
}

class BackgroundTaskManager
{
    private readonly List<Pet> _pets;
    private CancellationTokenSource _cancellationTokenSource;
    private bool _isRunning;

    public BackgroundTaskManager(List<Pet> pets)
    {
        _pets = pets;
        _cancellationTokenSource = new CancellationTokenSource();
    }

    public async Task StartStatDecayTask()
    {
        if (_isRunning) return;
        _isRunning = true;

        string[] trashTalk = {
            "Your pets are starving, bro. Do something.",
            "No sleep = grumpy pet. You want that?",
            "If you don’t let 'em have fun, they’ll go into pet depression.",
            "Your pets are gonna die if you ignore them. Just sayin'."
        };

        while (!_cancellationTokenSource.Token.IsCancellationRequested)
        {
            Console.WriteLine($"
[Reminder] {trashTalk[new Random().Next(trashTalk.Length)]}");

            foreach (var pet in _pets)
            {
                if (pet.IsDead) continue;
                pet.DecreaseStat(StatType.Hunger, 5);
                pet.DecreaseStat(StatType.Sleep, 3);
                pet.DecreaseStat(StatType.Fun, 4);
                pet.UpdateHealth();
            }

            await Task.Delay(10000, _cancellationTokenSource.Token);
        }
    }

    public void StopTasks()
    {
        _cancellationTokenSource.Cancel();
        _isRunning = false;
    }
}

class PetManager
{
    private List<Pet> pets = new();
    private readonly BackgroundTaskManager _backgroundTaskManager;

    public PetManager()
    {
        _backgroundTaskManager = new BackgroundTaskManager(pets);
        _ = _backgroundTaskManager.StartStatDecayTask();
    }

    public void AdoptPet()
    {
        Console.Write("Name your new chaos companion: ");
        string? name = Console.ReadLine();
        if (string.IsNullOrWhiteSpace(name)) name = "NoName";

        var pet = new Pet(name);
        pets.Add(pet);
        Console.WriteLine($"{pet.GetStatusIcon()}{name} has joined the squad.
");
    }

    public void DisplayPets()
    {
        if (pets.Count == 0)
        {
            Console.WriteLine("No pets in the crew yet. Adopt one, lazybones.");
            return;
        }

        Console.WriteLine("
== Your Pet Roster ==");
        foreach (var pet in pets)
        {
            Console.WriteLine(pet.ToString());
        }
        Console.WriteLine();
    }

    public async Task UseItemAsync()
    {
        if (pets.Count == 0)
        {
            Console.WriteLine("You got no pets. Who you tryna help, the air?");
            return;
        }

        Console.WriteLine("
== Available Items ==");
        for (int i = 0; i < ItemDatabase.Items.Count; i++)
        {
            var item = ItemDatabase.Items[i];
            Console.WriteLine($"{i + 1}. {item.Name} (Effect: +{item.EffectAmount} {item.StatAffected})");
        }

        Console.Write("
Pick an item (number): ");
        if (!int.TryParse(Console.ReadLine(), out int itemIndex) || itemIndex < 1 || itemIndex > ItemDatabase.Items.Count)
        {
            Console.WriteLine("Nah. Try again.");
            return;
        }

        Console.WriteLine("
Which pet needs the goods?");
        for (int i = 0; i < pets.Count; i++)
        {
            Console.WriteLine($"{i + 1}. {pets[i].Name}");
        }

        Console.Write("
Pick a pet (number): ");
        if (!int.TryParse(Console.ReadLine(), out int petIndex) || petIndex < 1 || petIndex > pets.Count)
        {
            Console.WriteLine("Invalid choice. Read better.");
            return;
        }

        var selectedItem = ItemDatabase.Items[itemIndex - 1];
        var selectedPet = pets[petIndex - 1];

        if (selectedPet.IsDead)
        {
            Console.WriteLine("Bruh... that pet is dead. Let them rest.");
            return;
        }

        selectedPet.IncreaseStat(selectedItem.StatAffected, selectedItem.EffectAmount);
        Console.WriteLine($"
Used {selectedItem.Name} on {selectedPet.Name}. Nice.");

        await Task.Delay(1000);
        Console.WriteLine($"New stats: {selectedPet}");
    }

    public void Cleanup()
    {
        _backgroundTaskManager.StopTasks();
    }
}

class Program
{
    static async Task Main(string[] args)
    {
        var manager = new PetManager();

        while (true)
        {
            Console.WriteLine("
=== Pet Control Center ===");
            Console.WriteLine("1. Adopt a pet");
            Console.WriteLine("2. Show all pets");
            Console.WriteLine("3. Use an item");
            Console.WriteLine("4. Exit");

            Console.Write("
Choose: ");
            var choice = Console.ReadLine();

            switch (choice)
            {
                case "1":
                    manager.AdoptPet();
                    break;
                case "2":
                    manager.DisplayPets();
                    break;
                case "3":
                    await manager.UseItemAsync();
                    break;
                case "4":
                    manager.Cleanup();
                    Console.WriteLine("Peace out.");
                    return;
                default:
                    Console.WriteLine("Pick something legit.");
                    break;
            }
        }
    }
}
